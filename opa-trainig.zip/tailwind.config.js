/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      scale: {
        '101': '1.02',
      },
      colors: {
        'primary': {
          100: '#34b7e1',
          200: '#1166b0',
        },
        'secondary': {
          100: '#1d3340',
          200: '#16242b',
        }
      },
    },
  },
  plugins: [],
}

