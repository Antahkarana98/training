import { create } from 'zustand';
import { Course, CourseWithVideo } from './src/types';
import { getCourses, getCourse } from './src/services/coursesServices';
import { devtools } from 'zustand/middleware';

type CoursesStore = {
  courses: CourseWithVideo[]
  course: Course[]
  fetchCourses: () => Promise<void>
  fetchCourse: (title: string) => Promise<void>
}

export const useCoursesStore = create<CoursesStore>()(devtools((set) => ({
  courses: [],
  course: [],
  fetchCourses: async () => {
    const courses = await getCourses()

    set({ courses })
  },

  fetchCourse: async (title) => {
    const course = await getCourse(title)
    
    set({course})
  }
})))