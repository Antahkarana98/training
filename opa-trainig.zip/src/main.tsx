import React from 'react'
import ReactDOM from 'react-dom/client'
import './index.css'
import { createBrowserRouter, RouterProvider } from 'react-router-dom'
import HomePage from './pages/HomePage'
import Layout from './Layouts/Layout'
import CoursePage from './pages/CoursePage'
import AllTopics from './pages/AllTopics'

const routes = ([
  {
    path: '/',
    element: <Layout />,
    children: [
      {
        path: '/',
        element: <HomePage />
      },
      {
        path: '/temas',
        element: <AllTopics />
      },
      {
        path: '/curso/:title/:sectionName',
        element: <CoursePage />
      }
    ]
  }
])

export const router = createBrowserRouter( routes, {
  /* basename: '/Web' */
} )


ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <RouterProvider router={router} />
  </React.StrictMode>,
)
