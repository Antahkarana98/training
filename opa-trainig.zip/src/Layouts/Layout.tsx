import { Outlet } from "react-router-dom"
import Nav from "../components/Nav"
import { useEffect } from "react"
import { useCoursesStore } from "../../store"

const Layout = () => {

  const { fetchCourses } = useCoursesStore();

  useEffect(() => {
    fetchCourses();
  }, []);


  return (
    <>
      <div className="w-3/4 mx-auto">

        <header>
          <Nav />
        </header>

        <main className="mt-20">
          <Outlet />
        </main>
        
        {/* <footer>
          <h1>Footer</h1>
        </footer> */}
      </div>

    </>
  )
}

export default Layout