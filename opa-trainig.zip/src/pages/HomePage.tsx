import { useState } from "react"
import { Link } from "react-router-dom";

import { useCoursesStore } from '../../store';

import SearchBar from "../components/SearchBar"
import CardCategory from "../components/CardCategory";

const HomePage = () => {
  const [searchTerm, setSearchTerm] = useState("");

  const { courses } = useCoursesStore();

  function removeAccents(str : string) {
    return str.normalize("NFD").replace(/[\u0300-\u036f]/g, "");
  }
  
  const filteredCourses = courses.filter((course) => {
    return removeAccents(course.courseName.toLowerCase()).includes(removeAccents(searchTerm.toLowerCase()));
  });
  
  const handleSearch = (term : string) => {
    setSearchTerm(term);
  };

  return (
    <>
      <section className="mt-5 mx-auto">
        <section className="">
          <h2 className="text-3xl mb-6 font-medium text-center text-white">Buscar un tema específico</h2>
          <SearchBar onSearch={ handleSearch } />
        </section>

        <section className="mx-auto mt-16 w-2/4">
          <p className="roboto-font text-2xl text-white font-bold text-center"><span className="text-primary-100 text-3xl">OPA TRAINING</span> es un espacio para generar o reforzar nuevos conocimientos sobre la operatividad y el modelo de negocio de la compañía</p>
        </section>

        <section>

          <div className="grid grid-cols-4 gap-3 mt-16">
            { 
              filteredCourses.length === 0 && searchTerm.length !== 0 ? (

                <div className="text-center col-span-5 mt-10">
                  <h2 className="text-2xl font-bold">No hay resultados...</h2>
                </div>

              ) : (
                filteredCourses.slice(0, 8).map((course) => (
                  <div key={course.id} className="">
                    <CardCategory
                      title={course.courseName}
                      category={course.category}
                      instructor={course.instructor}
                      sections={course.courseContent}
                      quantityVideos={course.quantityVideos}
                    />
                  </div>
                ))
              )
            }
          </div>
        </section> 
      </section>

      <section className="mb-10 mx-auto w-1/4 mt-10">
        <Link to="/temas" className="text-3xl hover:border-b-2 border-white text-white text-center">Ver todos los temas <span className="text-2xl">&gt;</span></Link>
      </section>
    </>
  )
}

export default HomePage
