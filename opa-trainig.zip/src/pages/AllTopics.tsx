import { useCoursesStore } from "../../store"
import CardCategory from "../components/CardCategory"
import ModalCourse from "../components/ModalCourse"

const AllTopics = () => {

  const { courses } = useCoursesStore()

  return (
    <section className="h-full overflow-hidden">
      <ModalCourse />
      <div className="grid grid-cols-4 gap-3 h-full overflow-y-auto py-3 pe-3" style={{ maxHeight: 'calc(100vh - 35vh)' }}>
        {courses.map((course) => (
          <CardCategory
            key={course.id}
            title={course.courseName}
            category={course.category}
            instructor={course.instructor}
            sections={course.courseContent}
            quantityVideos={course.quantityVideos}
          />
        ))}
      </div>
    </section>
  )
}

export default AllTopics