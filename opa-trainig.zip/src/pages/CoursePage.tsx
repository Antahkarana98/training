import { act, useEffect, useMemo, useRef, useState } from 'react'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faChevronDown, faChevronUp, faCirclePlay, faCirclePause } from '@fortawesome/free-solid-svg-icons'
import { Swiper, SwiperSlide } from 'swiper/react'
import { Swiper as SwiperType  } from 'swiper/types';
import { useParams } from 'react-router-dom'
import { useCoursesStore } from '../../store';
import image1 from '../assets/1.png'
import image2 from '../assets/2.png'
import image3 from '../assets/3.jpg'
import image4 from '../assets/4.jpg'
import image5 from '../assets/5.jpg'
import image6 from '../assets/6.jpg'

import 'swiper/css';
import 'swiper/css/pagination';
import { Content, SectionContent } from '../types';

const CoursePage = () => {

  const { fetchCourse } = useCoursesStore(state => state)
  const { course } = useCoursesStore(state => state)

  const [activeSlideContent, setActiveSlideContent] = useState('')
  const [activeSlideIndex, setActiveSlideIndex] = useState(0)


  const { title, sectionName } = useParams<{ sectionName: string, title: string }>()
  
  const hasCourse = useMemo(() => course.length > 0, [course])
  const selectedVideo = useMemo(() => {
    if (course.length === 0) return
    const section = course[0].courseContent.find((section: SectionContent) => section.sectionName === sectionName)
    return section?.content.find((content: Content) => content.title === activeSlideContent) || section?.content[0]
  }, [activeSlideContent, course, sectionName])

  const selectedSectionName = useMemo(() => {
    if (course.length === 0) return    
    return course[0].courseContent.find((section: SectionContent) => section.sectionName === sectionName) || course[0].courseContent[0]
  }, [course, sectionName])

  useEffect(() => {
    fetchCourse(title!)    
  }, [])

  const swiperRef = useRef<SwiperType | null>(null);
  const swiperRef2 = useRef<SwiperType | null>(null);

  const handleSlideClick = (content: string, index: number) => {
    setActiveSlideContent(content)
    if (swiperRef.current && swiperRef.current?.swiper) {
      swiperRef.current.swiper.slideTo(index)
    }
    if (swiperRef2.current && swiperRef2.current?.swiper) {
      swiperRef2.current.swiper.slideTo(index)
    }
    setActiveSlideIndex(index)
  }

  const images = [image1, image2, image3, image4, image5, image6];

  // Función para sacar una imagen aleatoria
  const getRandomImage = () => {
    return images[Math.floor(Math.random() * images.length)];
  }

  return (
    <>
      { !hasCourse ? (<h2>Loading...</h2>) : (

        <div className='mx-auto mt-10'>
          <section className='grid grid-cols-4 items-center gap-10'>
            <div style={{height: "88vh"}} className='w-full col-span-3'>
              <h1 className='text-3xl mb-5 font-bold text-white roboto-font'><span className='text-primary-100'>{selectedSectionName?.sectionName}</span> - {selectedVideo?.title}</h1>
              <video className='w-full h-3/5 shadow-lg' key={selectedVideo?.video} controls>
                <source src={selectedVideo?.video} type="video/mp4" />
              </video>

              <div className='mt-5'>
                <p className='text-white text-xl roboto-font font-medium'>
                  Lorem ipsum dolor, sit amet consectetur adipisicing elit. Et laboriosam voluptatem dolore culpa? Delectus eius nisi laudantium est ducimus non, aperiam veniam ipsum, natus numquam reiciendis distinctio et, harum expedita!
                </p>
              </div>
            </div>

            <div style={{height: "88vh"}}>
              
                <div>
                  <button 
                    className={'button-custom-slide-down'} 
                    onClick={() => {
                      swiperRef2.current?.slidePrev();
                      swiperRef.current?.slidePrev();                 
                    }}
                    ><FontAwesomeIcon icon={ faChevronUp } /></button>
                </div>

                <Swiper
                  direction={'vertical'}
                  slidesPerView={3}
                  className="mySwiper"
                  onBeforeInit={(swiper) => {
                    swiperRef2.current = swiper;
                  }}
                  spaceBetween={10}
                >
                
                  {
                    selectedSectionName?.content.map((content: Content, index:number) => (
                      <SwiperSlide key={content.title}>
                        <div className='flex justify-center h-full bg-transparent'>

                          <div onClick={() => handleSlideClick(content.title, index)} className={`${activeSlideIndex === index ? 'text-blue-500 w-full' : 'styleCardSwiper'} transition-all duration-500 relative flex items-center justify-center text-white cursor-pointer h-full rounded-lg `}>
                            <div className={`${activeSlideIndex === index ? 'opacity-70' : 'opacity-40'} bg-black absolute -z-10 h-full w-full rounded-lg`}></div>
                            <img className='absolute -z-20 rounded-lg bg-cover bg-center bg-no-repeat' src={image1} /* src={getRandomImage()} */ alt="" />
                            <div>
                              {activeSlideIndex === index ? <FontAwesomeIcon icon={faCirclePause} className='text-5xl' /> : <FontAwesomeIcon icon={ faCirclePlay } className='text-5xl' />}
                            </div>
                          </div>
                        </div>
                      </SwiperSlide>
                    ))
                  }
                  
                </Swiper>

                <div>
                  <button 
                    className={'button-custom-slide-up'} 
                    onClick={() => {
                      swiperRef2.current?.slideNext();
                      swiperRef.current?.slideNext();
                    }}
                  >
                    <FontAwesomeIcon icon={ faChevronDown } /></button>
                </div>
            </div>
          </section>
        </div>
      )}
    </>
    
  )
}

export default CoursePage