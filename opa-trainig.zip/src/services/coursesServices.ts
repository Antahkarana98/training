import axios from "axios";
import { CoursesSchema } from '../schemas/courses-schema';
import { Course, CourseWithVideo } from "../types";

export const getCourses = async () => {
  const url = "http://localhost:5001/courses";
  const { data } = await axios(url);

  const result = CoursesSchema.safeParse(data);
  const courses : CourseWithVideo[] = []

  if (result.success) {
    result.data.forEach((course: Course) => {
      let quantityVideos = 0;
      course.courseContent.forEach((section) => {
        quantityVideos += section.content.length;
      });
      courses.push({ ...course, quantityVideos });
    });
    
    return courses 
  } else {
    console.error('Failed to parse courses data:', result.error);
  }
}

export const getCourse = async (title: string) => {
  const url = "http://localhost:5001/courses";
  const { data } = await axios(url);

  const course = data.filter((course: Course) => {
    return course.courseName === title;
  });
  
  return [course[0]];
}