import { z } from 'zod';


export const videoSchema = z.object({
  video: z.string(),
  title: z.string(),
  tags: z.array(z.string()),
});

export const sectionContentSchema = z.object({
  sectionName: z.string(),
  content: z.array(videoSchema),
});

export const courseSchema = z.object({
  category: z.string(),
  courseName: z.string(),
  instructor: z.string(),
  courseContent: z.array(sectionContentSchema),
  id: z.string(),
});

export const courseVideoSchema = courseSchema.extend({
  quantityVideos: z.number(),
});

export const CoursesSchema = z.array(courseSchema);
