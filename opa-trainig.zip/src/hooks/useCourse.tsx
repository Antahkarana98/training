import { useContext } from "react";

import { CoursesContext } from "../context/CoursesContext";

export const useCourse = () => {
  const context = useContext(CoursesContext);
  if (!context) {
    throw new Error("useCurse must be used within a CurseProvider");
  }
  return context; 
}