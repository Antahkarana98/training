import { z } from 'zod'
import { courseSchema, courseVideoSchema, sectionContentSchema, videoSchema } from '../schemas/courses-schema'

export type Course = z.infer<typeof courseSchema>
export type SectionContent = z.infer<typeof sectionContentSchema>
export type Content  = z.infer<typeof videoSchema>
export type CourseWithVideo = z.infer<typeof courseVideoSchema>
