import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faBook } from '@fortawesome/free-solid-svg-icons'
import { Link } from 'react-router-dom'

type CardModalProps = {
  section: {
    sectionName: string
  }
  title: string
  instructor: string
}

const CardModal = ({section, title, instructor} : CardModalProps) => {

  return (
    <>
    <Link to={`/curso/${title}/${section.sectionName}`} className="inline-flex items-center justify-between w-full  py-1 px-3 text-gray-900 bg-white border-b border-gray-200 cursor-pointer  hover:text-gray-900 hover:bg-gray-100">                                    
      <div className='grid grid-cols-5 items-center gap-5 w-full'>
        <div className='bg-primary-200 col-span-1 w-full h-full rounded-lg flex items-center justify-center'>
         <FontAwesomeIcon icon={faBook} className='text-white text-4xl'/>
        </div>
        <div className='col-span-4'>
          <h3 className='roboto-font font-bold text-lg'>{section.sectionName}</h3>
          <p className='roboto-font text-slate-500'>{instructor}</p>
        </div>
      </div>
    </Link>
    </>
  )
}

export default CardModal