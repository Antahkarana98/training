
import { useState } from 'react';
import { Modal } from 'antd';
/* import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faEllipsis } from '@fortawesome/free-solid-svg-icons'; */
import { SectionContent } from '../types';
import UserImage from '../assets/user.png';
import CardModal from './CardModal';

type CardCategoryProps = {
  title: string
  category: string
  instructor: string
  sections: SectionContent[]
  quantityVideos: number
}

const CardCategory = ({ title,instructor, sections, quantityVideos } : CardCategoryProps) => {

  const [isModalOpen, setIsModalOpen] = useState(false);
  
  const showModal = () => {
    setIsModalOpen(true)
  };

  const handleCancel = () => {
    setIsModalOpen(false)
  };

  return (
    <>
      <div onClick={ showModal } className="cursor-pointer max-w-sm bg-white border border-gray-200 rounded-xl shadow-lg hover:-translate-y-1 transition-all duration-500">
        <div className="px-5 pb-5 pt-3">

          <div className='flex items-center gap-5 relative'>
            <div>
              <img src={ UserImage } alt="Icono del tema o curso" />

            </div>

            <div>
              <h3 className="font-bold tracking-tight text-gray-900 roboto-font">{ title }</h3>
              <p className='text-sm text-slate-500 roboto-font'>{ instructor }</p>
            </div>

            {/* <div className='text-xl absolute right-0 top-0'>
              <FontAwesomeIcon icon={faEllipsis} />
            </div> */}

          </div>

          <div className='flex items-center justify-between mt-5'>
            <div className='text-secondary-200 text-2xl font-medium'>
              { sections.length } Cursos
            </div>
            <div className='text-primary-200 text-2xl font-medium'>
              { quantityVideos } Videos
            </div>
          </div>
        </div>
      </div> 

      <Modal 
        title={ title }
        open={isModalOpen} 
        onCancel={handleCancel}
        centered
        width={"25%"}
        footer={null}
      >
        <div>
          <ul className="mt-4 overflow-y-scroll" style={{ height: 'calc(100vh - 35vh)' }}>
            {
              sections.map((section, i) => (
                <li key={i} className=" pe-3">
                  <CardModal 
                    title={title}
                    instructor={instructor}
                    section={section}
                  />
                </li>
              ))
            }
          </ul>
        </div>

      </Modal>
    </>
  );
}

export default CardCategory
