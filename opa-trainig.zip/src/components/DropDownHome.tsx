import { DownOutlined } from '@ant-design/icons';
import type { MenuProps } from 'antd';
import { Dropdown, Space } from 'antd';
import { useCoursesStore } from "../../store"
import { Link } from 'react-router-dom';

const DropDownHome = () => {

  const { courses } = useCoursesStore()

  const items: MenuProps['items'] = courses.map((course) => ({
    key: course.id,
    label: (
      <Link to={`/curso/${course.courseName}/${course.courseContent[0].sectionName}`} rel="noopener noreferrer">
        {course.courseName}
      </Link>
    ),
  }))

  return (
    <Dropdown menu={{ items }}>
      <a onClick={(e) => e.preventDefault()}>
        <Space>
          Temas
          <span className='text-base'>
            <DownOutlined />
          </span>
        </Space>
      </a>
    </Dropdown>
  )
}

export default DropDownHome