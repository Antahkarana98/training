type SearchBarProps = {
  onSearch: (search: string) => void
}

const SearchBar = ({ onSearch }: SearchBarProps) => {
  
  return (
    <>
       <form>
        <label htmlFor="search" className="mb-2 text-sm font-medium text-gray-900 sr-only">Search</label>
        <div className="relative mx-auto">
          <input
            type="search"
            id="search"
            className="shadow-inner-white block w-full py-2 px-4 text-lg text-white border outline-none rounded-xl bg-search-bar"
            placeholder="Contabilidad Básica..."
            required
            onChange={(e) => onSearch(e.target.value)}
          />
        </div>
      </form>
    </>
  )
}

export default SearchBar
