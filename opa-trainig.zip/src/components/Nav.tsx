import { Link } from 'react-router-dom';

const Nav = () => {

  return (
    <>
      <nav className="grid grid-cols-3 gap-5 text-white mt-14">
        <div>
          <p className='text-5xl font-bold'>opa</p>
        </div>

        <div className='flex items-center justify-around'>
          <div >
            <Link to='/' className='link-nav text-xl'>Inicio</Link>
          </div>

          <div className='text-xl cursor-pointer'>
            <Link to='/temas' className='link-nav'>Temas</Link>
          </div>
        </div>

        <div className='flex justify-end items-center'>
          <Link to='/' className='text-black uppercase text-sm bg-white font-bold p-2 rounded-2xl'>Administrador</Link>
        </div>
      </nav>
    </>
  )
}

export default Nav
