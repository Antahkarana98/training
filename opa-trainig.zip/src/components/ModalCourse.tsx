import { useState } from 'react';
import { Button, Modal } from 'antd';

const ModalCourse = () => {
  const [isModalOpen, setIsModalOpen] = useState(false);

  const showModal = () => {
    setIsModalOpen(true);
  };

  const handleOk = () => {
    setIsModalOpen(false);
  };

  const handleCancel = () => {
    setIsModalOpen(false);
  };

  return (
    <>
      <Button type="primary" onClick={showModal}>
        Nuevo Curso
      </Button>
      <Modal
        title="Crear nuevo curso"
        open={isModalOpen}
        onCancel={handleCancel}
        footer={false}  
      >
        <form>
          <div>
            <label htmlFor="courseName">Course Name</label>
            <input type="text" id="courseName" name="courseName" />
          </div>

          <div>
            <label htmlFor="instructor">Instructor</label>
            <input type="text" id="instructor" name="instructor" />
          </div>

          <div>
            <label htmlFor="themes">Temas</label>
            <input type="text" id="themes" name="themes" />
          </div>
        </form>

        <button type='button' onClick={handleCancel}>Salir</button>
      </Modal>
    </>
  );
};

export default ModalCourse;